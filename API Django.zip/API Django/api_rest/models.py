from django.db import models

# Create your models here.

class Person(models.Model):
    
    person_id = models.CharField(primary_key=True, max_length=500, default='')
    person_name = models.CharField(max_length=150, default='')
    person_profession = models.CharField(max_length=150, default='')
    person_address = models.CharField(max_length=150, default='')
    person_contact = models.CharField(max_length=50, default='')

    def __str__(self):
        return f'ID: {self.person_id} | Nome do profissional: {self.person_name}'

class Consultation(models.Model):
    
    consultation_id = models.CharField(primary_key=True, max_length=500, default='')
    consultation_data = models.CharField(max_length=70, default='')
    consultation_person = models.CharField(max_length=150, default='')

    def __str__(self):
        return f'ID: {self.consultation_id} | Pessoa profissional vinculada: {self.consultation_person}' 