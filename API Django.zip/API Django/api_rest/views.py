from django.shortcuts import render
from django.http import HttpResponse, JsonResponse

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status

from .models import Person
from .models import Consultation

from .serializers import ConsultationSerializer
from .serializers import PersonSerializer

import json

@api_view(['GET'])
def get_persons(request):

    if request.method == 'GET':

        persons = Person.objects.all()

        serializer = PersonSerializer(persons, many=True)

        return Response(serializer.data)
    
    return Response(status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_consultations(request):

    if request.method == 'GET':

        consultations = Consultation.objects.all()

        serializer = ConsultationSerializer(consultations, many=True)

        return Response(serializer.data)
    
    return Response(status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
def get_by_person_id(request, id):

    try:
        person = Person.objects.get(pk=id)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':

        serializer = PersonSerializer(person)
        return Response(serializer.data)
    
@api_view(['GET'])
def get_by_consultation_id(request, id):

    try:
        consultation = Consultation.objects.get(pk=id)
    except:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':

        serializer = ConsultationSerializer(consultation)
        return Response(serializer.data)
    
@api_view(['GET','POST','PUT','DELETE'])
def person_manager(request):

    if request.method == 'GET':

        try:
            if request.GET['person']:                         # Check if there is a get parameter called 'user' (/?user=xxxx&...)

                person_id = request.GET['person']         # Find get parameter

                try:
                    person = Person.objects.get(pk=person_id)   # Get the object in database
                except:
                    return Response(status=status.HTTP_404_NOT_FOUND)

                serializer = PersonSerializer(person)           # Serialize the object data into json
                return Response(serializer.data)            # Return the serialized data

            else:
                return Response(status=status.HTTP_400_BAD_REQUEST)
            
        except:
            return Response(status=status.HTTP_400_BAD_REQUEST)

# CRIANDO DADOS
    if request.method == 'POST':

        new_person = request.data
        
        serializer = PersonSerializer(data=new_person)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
    
        return Response(status=status.HTTP_400_BAD_REQUEST)
    
    # EDITAR DADOS (PUT)

    if request.method == 'PUT':

        id = request.data['person_id']

        try:
            updated_person = Person.objects.get(pk=id)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)

        serializer = PersonSerializer(updated_person, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        
        return Response(status=status.HTTP_400_BAD_REQUEST)
    
    # DELETAR DADOS (DELETE)

    if request.method == 'DELETE':

        try:
            person_to_delete = PersonSerializer.objects.get(pk=request.data['person_id'])
            person_to_delete.delete()
            return Response(status=status.HTTP_202_ACCEPTED)
        except:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
        
@api_view(['GET','POST','PUT','DELETE'])
def consultation_manager(request):

    if request.method == 'GET':

        try:
            if request.GET['consultation']:                         # Check if there is a get parameter called 'user' (/?user=xxxx&...)

                consultation_id = request.GET['consultation']         # Find get parameter

                try:
                    consultation = Consultation.objects.get(pk=consultation_id)   # Get the object in database
                except:
                    return Response(status=status.HTTP_404_NOT_FOUND)

                serializer = ConsultationSerializer(consultation)           # Serialize the object data into json
                return Response(serializer.data)            # Return the serialized data

            else:
                return Response(status=status.HTTP_400_BAD_REQUEST)
            
        except:
            return Response(status=status.HTTP_400_BAD_REQUEST)

# CRIANDO DADOS
    if request.method == 'POST':

        new_consultation = request.data
        
        serializer = ConsultationSerializer(data=new_consultation)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
    
        return Response(status=status.HTTP_400_BAD_REQUEST)
    
    # EDITAR DADOS (PUT)

    if request.method == 'PUT':

        id = request.data['consultation_id']

        try:
            updated_consultation = Consultation.objects.get(pk=id)
        except:
            return Response(status=status.HTTP_404_NOT_FOUND)

        serializer = ConsultationSerializer(updated_consultation, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        
        return Response(status=status.HTTP_400_BAD_REQUEST)
    
    # DELETAR DADOS (DELETE)

    if request.method == 'DELETE':

        try:
            consultation_to_delete = Consultation.objects.get(pk=request.data['consultation_id'])
            consultation_to_delete.delete()
            return Response(status=status.HTTP_202_ACCEPTED)
        except:
            return Response(status=status.HTTP_400_BAD_REQUEST)