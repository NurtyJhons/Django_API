from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('pessoas', views.get_persons, name='get_all_person'),
    path('consultas', views.get_consultations, name='get_all_consultations'),
    path('pessoas/<str:id>', views.get_by_person_id),
    path('consultas/<str:id>', views.get_by_consultation_id),
    path('pessoas/CRUD/', views.person_manager),
    path('consultas/CRUD/', views.consultation_manager)
]